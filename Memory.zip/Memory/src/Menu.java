import java.awt.Font;

import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;

import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.TrueTypeFont;

public class Menu {
	private static String score = null;
	private int element;
	private Case[] select;

	public Menu() {
		select = new Case[4];
		this.element = 0;
		for (int i = 0; i < select.length; i++) {
			if(i==3) {
				select[i] = new Case(150 + 160, 160 + 60 * i + 30 * i, 70, 300);
			}else if(i==1 || i==0){
				select[i] = new Case(150 + 160, 160 + 60 * i + 30 * i, 70, 240);
			}else {
				select[i] = new Case(150 + 160, 160 + 60 * i + 30 * i, 70, 180);
			}
		}
	}

	public void afficherMenu() throws SlickException {
		Font font = new Font("jokerman", Font.BOLD, 50);
		TrueTypeFont ttf = new TrueTypeFont(font, true);
		ttf.drawString(55 + 120, 55, "MEMORY CHALLENGE", Color.cyan);

		font = new Font("snap itc", Font.BOLD, 50);

		for (int i = 0; i < select.length; i++) {
			String nom = "";
			if (i == 0) {
				nom = "JOUER";
			} else if (i == 1) {
				nom = "THEME";
			} else if (i == 2) {
				nom = "AIDE";
			} else {
				nom = "QUITTER";
			}

			ttf = new TrueTypeFont(font, true);
			ttf.drawString(160 + 160, 160 + 90 * i, nom, Color.white);
		}

		font = new Font("snap itc", Font.TRUETYPE_FONT, 30);
		ttf = new TrueTypeFont(font, true);
		ttf.drawString(250, 550, "MEILLEUR SCORE : " + score, Color.red);

	}

	public int quelleCase(int x, int y) {
		int valeur = -1;
		for (int i = 0; i < select.length; i++) {
			if (x >= select[i].getX() && x <= select[i].getX() + select[i].getLargeur()) {
				if (y >= select[i].getY() && y <= select[i].getY() + select[i].getHauteur()) {
					valeur = i;
				}
			}
		}
		return valeur;
	}

	public void clicCase(int x, int y, Fenetre f) {
		int valeur = quelleCase(x, y);
		if (valeur != -1) {
			f.musicClick.play();
			element = valeur + 1;
		}

		if (element == 1 && Fenetre.isPartieEnCours() == false) {
			f.musicClick.play();
			element = -1;
		}
	}

	public void dessinerHover(GameContainer gc, Graphics g) {
		Input inp = gc.getInput();
		int x = inp.getMouseX();
		int y = inp.getMouseY();
		int valeur = quelleCase(x, y);
		if (valeur != -1) {
			g.setColor(new Color(216, 191, 216));
			g.fillRoundRect(select[valeur].getX(), select[valeur].getY(), select[valeur].getLargeur(),
					select[valeur].getHauteur(), 5);
		}

	}

	public int getElement() {
		return element;
	}

	public void setElement(int element) {
		this.element = element;
	}

	public static String getScore() {
		return score;
	}

	public static void setScore(String score) {
		Menu.score = score;
	}

}
