import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;

public class Case {
	private float x, y;
	private int hauteur, largeur, sensx = 1, sensy = 1;

	public Case(float x, float y, int hauteur, int largeur) {
		super();
		this.x = x;
		this.y = y;
		this.hauteur = hauteur;
		this.largeur = largeur;
	}

	public Case(int x, int y, int hauteur) {
		super();
		this.x = x;
		this.y = y;
		this.hauteur = hauteur;
	}

	public void deplacerCases(GameContainer gc, int delta) {

			this.setX(x + 20 * delta / 1000f * sensx);
			this.setY(y + 20 * delta / 1000f * sensy);
			if (this.y > gc.getHeight() - 140 && sensy>0|| this.y < 50 && sensy<0) {
				sensy *= -1;
			}
			if (this.x > gc.getWidth()-140 && sensx>0 || this.x < 50 && sensx<0) {
				sensx *= -1;
			}
	}

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public int getHauteur() {
		return hauteur;
	}

	public void setHauteur(int hauteur) {
		this.hauteur = hauteur;
	}

	public int getLargeur() {
		return largeur;
	}

	public void setLargeur(int largeur) {
		this.largeur = largeur;
	}
	
	

	public void setSensx(int sensx) {
		this.sensx = sensx;
	}

	public void setSensy(int sensy) {
		this.sensy = sensy;
	}

	public void dessinerCase(Graphics g) {
		g.setColor(Color.white);
		g.drawRoundRect(x + 5, y + 5, hauteur - 10, hauteur - 10, 10);
	}
}
