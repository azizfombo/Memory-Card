import java.awt.Font;

import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.TrueTypeFont;

public class Aide {
	private Case retour;

	public Aide() {
		retour = new Case(680, 5, 40, 160);
	}

	public int quelleRetour(int x, int y) {
		int valeur = -1;
		if (x >= retour.getX() && x <= retour.getX() + retour.getLargeur()) {
			if (y >= retour.getY() && y <= retour.getY() + retour.getHauteur()) {
				valeur = 1;
			}
		}
		return valeur;
	}

	public void clicRetour(int x, int y, Menu m, Fenetre f) {
		if (quelleRetour(x, y) != -1) {
			m.setElement(0);
			f.musicClick.play();
		}
	}

	public void dessinerAide(Graphics g) {
		g.setColor(Color.yellow);
		g.fillRect(40, 40, 810, 520);
		g.setColor(Color.blue);
		g.fillRect(50, 50, 790, 500);

		
		Font font = new Font("jokerman", Font.BOLD, 40);
		TrueTypeFont ttf = new TrueTypeFont(font, true);

		ttf.drawString(250, 70, "COMMENT JOUER?", Color.white);
		font = new Font("calibri", Font.BOLD, 25);
		ttf = new TrueTypeFont(font, true);
		
		ttf.drawString(160, 140, "MEMORY CARD est un jeu ou le but est de trouver deux à", Color.white);
		
		ttf.drawString(230, 170, "deux ou trois cartes egales dans un plateau!!!", Color.white);
		
		ttf.drawString(180, 230, "Cette version du jeu possede trois niveaux: ", Color.white);
		
		font = new Font("calibri", Font.BOLD, 27);
		ttf = new TrueTypeFont(font, true);
		
		ttf.drawString(130, 270, "** Le pemier niveau donne des cartes deux a deux egales: ", Color.white);
		
		ttf.drawString(130, 310, "** Le deuxième niveau donne des cartes trois a trois egales: ", Color.white);
		
		ttf.drawString(130, 360, "** Le troisième niveau donne des cartes qui se déplacent ", Color.white);
		
		ttf.drawString(300, 390, "et trois a trois egales", Color.white);
		
		
		

		
//		texte = "MEMORY CARD est un jeu ou le but est de trouver deux ou trois cartes egales dans un plateau!!!";
//		ttf.drawString(150, 120, texte, Color.white);
		
		
		
		
		
		
		
		
		
		
		font = new Font("algerian", Font.BOLD, 35);
		ttf = new TrueTypeFont(font, true);
		ttf.drawString(retour.getX(), retour.getY(), "RETOUR", Color.white);
	}

	public void dessinerHover(GameContainer gc, Graphics g) {
		Input inp = gc.getInput();
		int x = inp.getMouseX();
		int y = inp.getMouseY();
		if(quelleRetour(x, y)==1) {
			g.setColor(new Color(255, 255, 255, 200));
			g.fillRoundRect(retour.getX(),retour.getY(), retour.getLargeur(), retour.getHauteur(), 5);
		}
	
	}
}
