import java.awt.Font;

import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.TrueTypeFont;

public class Theme {
	private Case[][] cases = new Case[2][3];
	private Cards[][] cartes = new Cards[2][3];
	private Case retour;

	public Theme() throws SlickException {
		retour = new Case(680, 5, 40, 160);

		//////////////////////////////////////////////////////////////
		int x = 50, y = 120;
		double element = 1;
		for (int i = 0; i < cases.length; i++) {
			for (int j = 0; j < cases[i].length; j++) {
				cases[i][j] = new Case(x + 50, y, 185, 180);
				cartes[i][j] = new Cards(element, x + 57, y + 7);
				x += 175 + 45;
				element++;

			}
			x = 50;
			y += 180 + 90;
		}
	}

	public void dessinerTheme(Graphics g) throws SlickException {
		g.drawImage(new Image("Images/theme.jpg"), 0, 0);
		for (int i = 0; i < cases.length; i++) {
			if (i == 0) {
				Font font = new Font("calibri", Font.BOLD, 50);
				TrueTypeFont ttf = new TrueTypeFont(font, true);
				ttf.drawString(75 + 120, 55, "THEME DES CARTES", Color.blue);
			} else {
				Font font = new Font("calibri", Font.BOLD, 50);
				TrueTypeFont ttf = new TrueTypeFont(font, true);
				ttf.drawString(75 + 120, 330, "THEME DU VERSEAUX", Color.blue);
			}
			for (int j = 0; j < cases[i].length; j++) {
				cases[i][j].dessinerCase(g);
				cartes[i][j].dessineCarte(g);
			}
		}
	}

	public boolean quelleRetour(int x, int y) {
		boolean estClic = false;
		if (x >= retour.getX() && x <= retour.getX() + retour.getLargeur()) {
			if (y >= retour.getY() && y <= retour.getY() + retour.getHauteur()) {
				estClic = true;
			}
		}
		return estClic;
	}

	public void retour(Menu m, int x, int y, Fenetre f) {
		boolean estClic = quelleRetour(x, y);
		if (estClic) {
			m.setElement(0);
			f.musicClick.play();
		}
	}

	public int[] quelleCase(int x, int y) {
		int[] tab = new int[2];
		tab[0] = -1;
		tab[1] = -1;
		for (int i = 0; i < cases.length; i++) {
			for (int j = 0; j < cases[i].length; j++) {
				if (x >= cases[i][j].getX() && x <= cases[i][j].getX() + cases[i][j].getLargeur())
					tab[1] = j;
				if (y >= cases[i][j].getY() && y <= cases[i][j].getY() + cases[i][j].getHauteur())
					tab[0] = i;
			}
		}
		return tab;
	}

	public void clicCase(int x, int y) {
		int[] tab = quelleCase(x, y);
		if (tab[0] != 1 && tab[1] != -1) {
			if (tab[0] == 0) {
				if (tab[1] == 0) {
					Cards.setThemevoir(0);
				}
				if (tab[1] == 1) {
					Cards.setThemevoir(1);
				}
				if (tab[1] == 2) {
					Cards.setThemevoir(2);
				}
			} else {
				if (tab[1] == 0) {
					Cards.setThemecache(0);
				}
				if (tab[1] == 1) {
					Cards.setThemecache(1);
				}
				if (tab[1] == 2) {
					Cards.setThemecache(2);
				}
			}
		}
	}

	public void dessinerHover(Graphics g, GameContainer gc) {
		Input inp = gc.getInput();
		int x = inp.getMouseX();
		int y = inp.getMouseY();
		int tab[] = quelleCase(x, y);
		if (tab[0] != -1 && tab[1] != -1) {
			g.setColor(new Color(255, 255, 255, 150));
			g.fillRoundRect(cases[tab[0]][tab[1]].getX(), cases[tab[0]][tab[1]].getY(),
					cases[tab[0]][tab[1]].getLargeur() + 10, cases[tab[0]][tab[1]].getHauteur() + 10, 5);
		}
		boolean b = this.quelleRetour(x, y);
		if (b) {
			g.setColor(new Color(255, 255, 255, 200));
			g.fillRoundRect(retour.getX(), retour.getY(), retour.getLargeur(), retour.getHauteur(), 5);
		}
		Font font = new Font("algerian", Font.BOLD, 40);
		TrueTypeFont ttf = new TrueTypeFont(font, true);
		ttf.drawString(retour.getX(), retour.getY(), "RETOUR", Color.white);
	}

	/*
	 * 
	 * 
	 * 
	 * 
	 * */

}
