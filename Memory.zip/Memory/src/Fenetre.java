import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Sound;
import org.newdawn.slick.TrueTypeFont;

public class Fenetre {
	private static boolean multijoueur;
	private static boolean partieEnCours;
	private int tentativeJ1;
	private int scoreJ1;
	private int tentativeJ2;
	private int scoreJ2;
	private Case retour;
	private Case recommencer;
	private Cards[][] cartes1;
	private Case[][] cases1;

	private Case[][] cases2;
	private Cards[][] cartes2;

	private Case[][] cases3;
	private Cards[][] cartes3;

	private int[] click1;
	private int[] click2;
	private int[] click3;

	private boolean joueurs = true;

	static BufferedReader lecture = null;
	static PrintWriter ecriture = null;

	Sound musicReussi = new Sound("Musics/bravo.ogg");
	Sound musicClick = new Sound("Musics/click.ogg");
	Sound musicFalse = new Sound("Musics/faux.ogg");
	Sound musicRetourne = new Sound("Musics/retourne.ogg");
	Sound music = new Sound("Musics/sounds.ogg");

	
	/*
	 * Créer des tableaux dont les éléments sont deux a deux et trois a egaux*/
	public int[][] aleatoire() {
		int[][] tab = new int[3][24];
		int i = 0, cmpt = 0;

		///////////////////////////////////////////////////////////////////////////////////////////
		while (i < 16) {
			tab[0][i] = (int) (Math.random() * 8 + 1);
			for (int j = 0; j <= i; j++) {
				if (tab[0][i] == tab[0][j]) {
					cmpt++;
				}
			}
			if (cmpt <= 2) {
				i++;
			}
			cmpt = 0;
		}

		///////////////////////////////////////////////////////////////////////////////////
		i = 0;
		cmpt = 0;
		while (i < tab[1].length) {
			tab[1][i] = (int) (Math.random() * 8 + 1);
			for (int j = 0; j <= i; j++) {
				if (tab[1][i] == tab[1][j]) {
					cmpt++;
				}
			}
			if (cmpt <= 3) {
				i++;
			}
			cmpt = 0;
		}

		i = 0;
		cmpt = 0;
		while (i < 18) {
			tab[2][i] = (int) (Math.random() * 6 + 1);
			for (int j = 0; j <= i; j++) {
				if (tab[2][i] == tab[2][j]) {
					cmpt++;
				}
			}
			if (cmpt <= 3) {
				i++;
			}
			cmpt = 0;
		}

		return tab;
	}

	public Fenetre() throws SlickException {
		cartes1 = new Cards[4][4];
		cartes2 = new Cards[4][6];
		cartes3 = new Cards[3][6];
		cases1 = new Case[4][4];
		cases2 = new Case[4][6];
		cases3 = new Case[3][6];

		// Instanciation des objet permettant la lecture et l'ecritue de du meilleure score
		try {
			ecriture = new PrintWriter(new FileOutputStream("score.txt", true));
			lecture = new BufferedReader(new FileReader("score.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Création des cases et cartes de chaque niveau
		int[][] tab = aleatoire();
		for (int l = 0, i = 0, y = 51; l < cases1.length; l++, y = y + 120) {
			for (int c = 0, x = 120 + 70; c < 4; c++, x += 120, i++) {
				cases1[l][c] = new Case(x, y, 120);
				cartes1[l][c] = new Cards(tab[0][i], x + 5, y + 5);

			}
		}

		for (int l = 0, i = 0, y = 51; l < cases2.length; l++, y = y + 120) {
			for (int c = 0, x = 85; c < 6; c++, x += 120, i++) {
				cases2[l][c] = new Case(x, y, 120);
				cartes2[l][c] = new Cards(tab[1][i], x + 5, y + 5);
				
				//cartes2[l][c].setEsttourner(true);
			}
		}

		for (int l = 0, i = 0, y = 51; l < cases3.length; l++, y = y + 120) {
			for (int c = 0, x = 85; c < 6; c++, x += 120, i++) {
				cases3[l][c] = new Case(x, y, 120);
				cartes3[l][c] = new Cards(tab[2][i], x + 5, y + 5);
				double nombre = Math.random();
				double nombre1 = Math.random();
				if (nombre <= 0.5) {
					cases3[l][c].setSensx(-1);
				}
				if (nombre1 <= 0.5) {
					cases3[l][c].setSensy(-1);
				}
				
				//cartes3[l][c].setEsttourner(true);
			}
		}

		tentativeJ1 = 0;
		tentativeJ2 = 0;
		scoreJ1 = 0;
		scoreJ2 = 0;

		partieEnCours = false;
		recommencer = new Case(0, 0, 40, 300);
		retour = new Case(720, 5, 40, 160);

	}

	/*Methode pour faire deplacer les cartes au niveau 3*/
	public void deplacerLesCartes(GameContainer gc, int delta) {
		for (int i = 0; i < cases3.length; i++) {
			for (int j = 0; j < cases3[i].length; j++) {
				if (cases3[i][j] != null && cartes3[i][j] != null) {
					cases3[i][j].deplacerCases(gc, delta);
					cartes3[i][j].deplacerCartes(cases3[i][j]);
				}
			}
		}
	}

	public void dessinerFenetre(Graphics g, Menu m) throws SlickException {
		if (m.getElement() == 1) {
			g.drawImage(new Image("Images/fenetre1.jpg"), 0, 0);
			for (int i = 0; i < cases1.length; i++) {
				for (int j = 0; j < cases1[i].length; j++) {
					if (cartes1[i][j] != null) {
						cartes1[i][j].dessinerCarte(g);
					}
				}
			}
		} else if (m.getElement() == 5) {
			g.drawImage(new Image("Images/fenetre2.jpg"), 0, 0);
			for (int i = 0; i < cases2.length; i++) {
				for (int j = 0; j < cases2[i].length; j++) {
					if (cartes2[i][j] != null) {
						cartes2[i][j].dessinerCarte(g);
					}
				}
			}
			if (click1 != null && cartes2[click1[0]][click1[1]].istourner() == false) {
				g.setColor(new Color(255, 255, 255, 120));
				g.fillRoundRect(cases2[click1[0]][click1[1]].getX(), cases2[click1[0]][click1[1]].getY(),
						cases2[click1[0]][click1[1]].getHauteur(), cases2[click1[0]][click1[1]].getHauteur(), 5);
			}
			if (click2 != null && cartes2[click2[0]][click2[1]].istourner() == false) {
				g.setColor(new Color(255, 255, 255, 120));
				g.fillRoundRect(cases2[click2[0]][click2[1]].getX(), cases2[click2[0]][click2[1]].getY(),
						cases2[click2[0]][click2[1]].getHauteur(), cases2[click2[0]][click2[1]].getHauteur(), 5);
			}
		} else if (m.getElement() == 6) {
			g.drawImage(new Image("Images/fenetre3.jpg"), 0, 0);
			for (int i = 0; i < cases3.length; i++) {
				for (int j = 0; j < cases3[i].length; j++) {
					if (cartes3[i][j] != null) {
						cartes3[i][j].dessinerCarte(g);
					}
				}
			}
			if (click1 != null && cartes3[click1[0]][click1[1]].istourner() == false) {
				g.setColor(new Color(255, 255, 255, 120));
				g.fillRoundRect(cases3[click1[0]][click1[1]].getX(), cases3[click1[0]][click1[1]].getY(),
						cases3[click1[0]][click1[1]].getHauteur(), cases3[click1[0]][click1[1]].getHauteur(), 5);
			}
			if (click2 != null && cartes3[click2[0]][click2[1]].istourner() == false) {
				g.setColor(new Color(255, 255, 255, 120));
				g.fillRoundRect(cases3[click2[0]][click2[1]].getX(), cases3[click2[0]][click2[1]].getY(),
						cases3[click2[0]][click2[1]].getHauteur(), cases3[click2[0]][click2[1]].getHauteur(), 5);
			}
		}
		Font font = new Font("snap itc", Font.BOLD, 17);
		TrueTypeFont ttf = new TrueTypeFont(font, true);

		if (multijoueur) {
			ttf.drawString(120, 550, "Joueur 1:", Color.red);
			ttf.drawString(0, 580, "TentativesJ1 : " + tentativeJ1, Color.red);
			ttf.drawString(200, 580, "SCOREJ1 : " + scoreJ1, Color.red);
			ttf.drawString(680, 550, "Joueur 2:", Color.red);
			ttf.drawString(500, 580, "TentativesJ2 : " + tentativeJ2, Color.red);
			ttf.drawString(720, 580, "SCOREJ2 : " + scoreJ2, Color.red);
		} else {
			ttf.drawString(370, 550, "Joueur 1:", Color.red);
			ttf.drawString(220, 580, "TentativesJ1  : " + tentativeJ1, Color.red);
			ttf.drawString(470, 580, "SCOREJ1 : " + scoreJ1, Color.red);
		}

	}

	//Methode qui vérifie qu'un niveau est vide pour passer au suivant
	public boolean fenetreVide(Menu m) {
		if (m.getElement() == 1) {
			for (int i = 0; i < cartes1.length; i++) {
				for (int j = 0; j < cartes1[i].length; j++) {
					if (cartes1[i][j] != null) {
						return false;
					}
				}
			}
		} else if (m.getElement() == 5) {
			for (int i = 0; i < cartes2.length; i++) {
				for (int j = 0; j < cartes2[i].length; j++) {
					if (cartes2[i][j] != null) {
						return false;
					}
				}
			}
		} else if (m.getElement() == 6) {
			for (int i = 0; i < cartes3.length; i++) {
				for (int j = 0; j < cartes3[i].length; j++) {
					if (cartes3[i][j] != null) {
						return false;
					}
				}
			}
		}
		return true;
	}

	
	//Elle permet de vérifier si la case sélectionnés existe selon les niveaux
	public int[] quelleCase(int x, int y, Menu m) {
		int[] tab = new int[2];
		tab[0] = -1;
		tab[1] = -1;
		if (m.getElement() == 1) {
			for (int i = 0; i < cases1.length; i++) {
				for (int j = 0; j < cases1[i].length; j++) {
					if (cases1[i][j] != null && x >= cases1[i][j].getX()
							&& x <= cases1[i][j].getX() + cases1[i][j].getHauteur() && y >= cases1[i][j].getY()
							&& y <= cases1[i][j].getY() + cases1[i][j].getHauteur()) {
						tab[1] = j;
						tab[0] = i;
					}

				}
			}
		} else if (m.getElement() == 5) {
			for (int i = 0; i < cases2.length; i++) {
				for (int j = 0; j < cases2[i].length; j++) {
					if (cases2[i][j] != null && x >= cases2[i][j].getX()
							&& x <= cases2[i][j].getX() + cases2[i][j].getHauteur() && y >= cases2[i][j].getY()
							&& y <= cases2[i][j].getY() + cases2[i][j].getHauteur()) {
						tab[1] = j;
						tab[0] = i;
					}

				}
			}
		} else if (m.getElement() == 6) {
			for (int i = 0; i < cases3.length; i++) {
				for (int j = 0; j < cases3[i].length; j++) {
					if (cases3[i][j] != null && x >= cases3[i][j].getX()
							&& x <= cases3[i][j].getX() + cases3[i][j].getHauteur() && y >= cases3[i][j].getY()
							&& y <= cases3[i][j].getY() + cases3[i][j].getHauteur()) {
						tab[1] = j;
						tab[0] = i;
					}

				}
			}
		}
		return tab;

	}

	//RECUPERE LE PREMIER CLICK DE LA CARTES SELON LES NIVEAUX
	public void click1(int x, int y, Menu m) {
		int[] tab;
		if (m.getElement() == 1) {
			tab = quelleCase(x, y, m);
			if ((cartes1[tab[0]][tab[1]] != null) && (tab[0] != -1 && tab[1] != -1)) {
				click1 = tab;
				cartes1[tab[0]][tab[1]].setEsttourner(true);
				musicClick.play();
				musicRetourne.play();
			}
		} else if (m.getElement() == 5) {
			tab = quelleCase(x, y, m);
			if (cartes2[tab[0]][tab[1]] != null && tab[0] != -1 && tab[1] != -1) {
				click1 = tab;
				musicClick.play();
				musicRetourne.play();

			}
		} else if (m.getElement() == 6) {
			tab = quelleCase(x, y, m);
			if (cartes3[tab[0]][tab[1]] != null && tab[0] != -1 && tab[1] != -1) {
				click1 = tab;
				musicClick.play();
				musicRetourne.play();

			}

		}
	}

	
	//RECUPERE LE DEUXIEME CLICK DE LA CARTES SELON LES NIVEAUX
	public void click2(int x, int y, Menu m) {
		int[] tab;
		if (m.getElement() == 1) {
			tab = quelleCase(x, y, m);
			if (click1[0] == tab[0] && click1[1] == tab[1]) {
				// cartes1[click1[0]][click1[1]].setEsttourner(false);
				// click1 = null;
				musicClick.play();
			} else {
				if (cartes1[tab[0]][tab[1]] != null && tab[0] != -1 && tab[1] != -1) {
					click2 = tab;
					cartes1[tab[0]][tab[1]].setEsttourner(true);
					musicClick.play();
					musicRetourne.play();
				}
			}
		} else if (m.getElement() == 5) {
			tab = quelleCase(x, y, m);
			if (click1[0] == tab[0] && click1[1] == tab[1]) {
				click1 = null;
				musicClick.play();
			} else {
				if (cartes2[tab[0]][tab[1]] != null && tab[0] != -1 && tab[1] != -1) {
					click2 = tab;
					musicClick.play();
					musicRetourne.play();
				}
			}
		} else if (m.getElement() == 6) {
			tab = quelleCase(x, y, m);
			if (click1[0] == tab[0] && click1[1] == tab[1]) {
				click1 = null;
				musicClick.play();
			} else {
				if (cartes3[tab[0]][tab[1]] != null && tab[0] != -1 && tab[1] != -1) {
					click2 = tab;
					musicClick.play();
					musicRetourne.play();
				}
			}
		}
	}

	//RECUPERE LE TROISIEME CLICK DE LA CARTES SELON LES NIVEAUX
	public void click3(int x, int y, Menu m) {
		int[] tab;
		if (m.getElement() == 5) {
			tab = quelleCase(x, y, m);
			if ((click1[0] == tab[0] && click1[1] == tab[1]) || (click2[0] == tab[0] && click2[1] == tab[1])) {
				click1 = null;
				click2 = null;
				musicClick.play();
			} else {
				if ((tab[0] != -1 && tab[1] != -1) && (cartes2[tab[0]][tab[1]] != null)) {
					click3 = tab;
					cartes2[click1[0]][click1[1]].setEsttourner(true);
					cartes2[click2[0]][click2[1]].setEsttourner(true);
					cartes2[click3[0]][click3[1]].setEsttourner(true);
					musicClick.play();
					musicRetourne.play();
				}
			}
		} else if (m.getElement() == 6) {
			tab = quelleCase(x, y, m);
			if ((click1[0] == tab[0] && click1[1] == tab[1]) || (click2[0] == tab[0] && click2[1] == tab[1])) {
				click1 = null;
				click2 = null;
				musicClick.play();
			} else {
				if ((tab[0] != -1 && tab[1] != -1) && (cartes3[tab[0]][tab[1]] != null)) {
					click3 = tab;
					cartes3[click1[0]][click1[1]].setEsttourner(true);
					cartes3[click2[0]][click2[1]].setEsttourner(true);
					cartes3[click3[0]][click3[1]].setEsttourner(true);
					musicClick.play();
					musicRetourne.play();
				}
			}
		}
	}

	public void comparer(Menu m) throws InterruptedException {
		Thread.sleep(700);
		boolean b = joueurs;
		if (m.getElement() == 1) {
			if (cartes1[click1[0]][click1[1]].getType() == cartes1[click2[0]][click2[1]].getType()) {
				cases1[click1[0]][click1[1]] = null;
				cases1[click2[0]][click2[1]] = null;

				cartes1[click1[0]][click1[1]] = null;
				cartes1[click2[0]][click2[1]] = null;

				musicReussi.play();

				if (multijoueur) {
					if (joueurs) {
						scoreJ1 += 15;
					} else {
						scoreJ2 += 15;
					}
				} else {
					scoreJ1 += 15;
				}
				// scoreJ1 += 15;

			} else {
				cartes1[click1[0]][click1[1]].setEsttourner(false);
				cartes1[click2[0]][click2[1]].setEsttourner(false);

				musicFalse.play();

				if (multijoueur) {
					if (joueurs) {
						scoreJ1 -= 5;
						joueurs = !joueurs;
					} else {
						scoreJ2 -= 5;
						joueurs = !joueurs;
					}
				} else {
					scoreJ1 -= 5;
				}

			}
		}

		else if (m.getElement() == 5) {
			if (cartes2[click1[0]][click1[1]].getType() == cartes2[click2[0]][click2[1]].getType()
					&& cartes2[click2[0]][click2[1]].getType() == cartes2[click3[0]][click3[1]].getType()) {

				cartes2[click1[0]][click1[1]] = null;
				cartes2[click2[0]][click2[1]] = null;
				cartes2[click3[0]][click3[1]] = null;

				musicReussi.play();

				if (multijoueur) {
					if (joueurs) {
						scoreJ1 += 20;
					} else {
						scoreJ2 += 20;
					}
				} else {
					scoreJ1 += 20;
				}
				// scoreJ1 += 20;

			} else {
				cartes2[click1[0]][click1[1]].setEsttourner(false);
				cartes2[click2[0]][click2[1]].setEsttourner(false);
				cartes2[click3[0]][click3[1]].setEsttourner(false);

				musicFalse.play();

				if (multijoueur) {
					if (joueurs) {
						scoreJ1 -= 3;
						joueurs = !joueurs;
					} else {
						scoreJ2 -= 3;
						joueurs = !joueurs;
					}
				} else {
					scoreJ1 -= 3;
				}
				// scoreJ1 -= 3;

			}
		} else if (m.getElement() == 6) {
			if (cartes3[click1[0]][click1[1]].getType() == cartes3[click2[0]][click2[1]].getType()
					&& cartes3[click2[0]][click2[1]].getType() == cartes3[click3[0]][click3[1]].getType()) {

				cartes3[click1[0]][click1[1]] = null;
				cartes3[click2[0]][click2[1]] = null;
				cartes3[click3[0]][click3[1]] = null;

				musicReussi.play();

				if (multijoueur) {
					if (joueurs) {
						scoreJ1 += 30;
					} else {
						scoreJ2 += 30;
					}
				} else {
					scoreJ1 += 30;
				}
				// scoreJ1 += 20;

			} else {
				cartes3[click1[0]][click1[1]].setEsttourner(false);
				cartes3[click2[0]][click2[1]].setEsttourner(false);
				cartes3[click3[0]][click3[1]].setEsttourner(false);

				musicFalse.play();

				if (multijoueur) {
					if (joueurs) {
						scoreJ1 -= 1;
						joueurs = !joueurs;
					} else {
						scoreJ2 -= 1;
						joueurs = !joueurs;
					}
				} else {
					scoreJ1 -= 1;
				}
				// scoreJ1 -= 3;

			}
		}
		click1 = null;
		click2 = null;
		click3 = null;

		if (multijoueur) {
			if (b)
				tentativeJ1++;
			else
				tentativeJ2++;
		} else {
			tentativeJ1++;
		}
		// tentativeJ1++;

	}

	//SI ON CLIQUE SUR LA CLASSE RECOMMMENCER
	public int quelleRecommencer(int x, int y) {
		int valeur = -1;
		if (x >= recommencer.getX() && x <= recommencer.getX() + recommencer.getLargeur()) {
			if (y >= recommencer.getY() && y <= recommencer.getY() + recommencer.getHauteur()) {
				valeur = 1;
			}
		}
		return valeur;
	}

	public boolean isRecommencer(int x, int y, Menu m) {
		if (quelleRecommencer(x, y) != -1) {
			return true;
		}
		return false;
	}

	//si on a cliqué sur recommencer, on modifie
	public void clicReccomencer(int x, int y, Menu m) {
		if (isRecommencer(x, y, m)) {
			partieEnCours = false;
			m.setElement(-1);
			musicClick.play();
		}
	}

	//SI ON CLIQUE SUR LA CASE RETOUR
	public int quelleRetour(int x, int y) {
		int valeur = -1;
		if (x >= retour.getX() && x <= retour.getX() + retour.getLargeur()) {
			if (y >= retour.getY() && y <= retour.getY() + retour.getHauteur()) {
				valeur = 1;
			}
		}
		return valeur;
	}
	
	//SI ON ACLIQUER SUR RETOUR ON MODIFIE
	public void clicRetour(int x, int y, Menu m) {
		if (quelleRetour(x, y) != -1) {
			m.setElement(0);
			musicClick.play();
		}
	}

	public void dessinerHover(GameContainer gc, Graphics g, Menu m) {
		Input inp = gc.getInput();
		int x = inp.getMouseX();
		int y = inp.getMouseY();
		if (m.getElement() == 1) {
			int tab[] = quelleCase(x, y, m);
			if (tab[0] != -1 && tab[1] != -1) {
				if (cartes1[tab[0]][tab[1]] != null) {
					g.setColor(new Color(255, 255, 255, 50));
					g.fillRoundRect(cases1[tab[0]][tab[1]].getX(), cases1[tab[0]][tab[1]].getY(),
							cases1[tab[0]][tab[1]].getHauteur(), cases1[tab[0]][tab[1]].getHauteur(), 5);
				}
			}
		}

		if (m.getElement() == 5) {
			int tab[] = quelleCase(x, y, m);
			if (tab[0] != -1 && tab[1] != -1) {
				if (cartes2[tab[0]][tab[1]] != null) {
					g.setColor(new Color(255, 255, 255, 50));
					g.fillRoundRect(cases2[tab[0]][tab[1]].getX(), cases2[tab[0]][tab[1]].getY(),
							cases2[tab[0]][tab[1]].getHauteur(), cases2[tab[0]][tab[1]].getHauteur(), 5);
				}
			}
		}
		if (m.getElement() == 6) {
			int tab[] = quelleCase(x, y, m);
			if (tab[0] != -1 && tab[1] != -1) {
				if (cartes3[tab[0]][tab[1]] != null) {
					g.setColor(new Color(255, 255, 255, 50));
					g.fillRoundRect(cases3[tab[0]][tab[1]].getX(), cases3[tab[0]][tab[1]].getY(),
							cases3[tab[0]][tab[1]].getHauteur(), cases3[tab[0]][tab[1]].getHauteur(), 5);
				}
			}
		}

		int ta = this.quelleRetour(x, y);
		if (ta != -1) {
			g.setColor(new Color(255, 255, 255, 200));
			g.fillRoundRect(retour.getX(), retour.getY(), retour.getLargeur(), retour.getHauteur(), 5);
		}

		if (quelleRecommencer(x, y) != -1) {
			g.setColor(new Color(255, 255, 255, 200));
			g.fillRoundRect(recommencer.getX(), recommencer.getY(), recommencer.getLargeur(), recommencer.getHauteur(),
					5);
		}
		Font font = new Font("algerian", Font.BOLD, 40);
		TrueTypeFont ttf = new TrueTypeFont(font, true);
		ttf.drawString(retour.getX(), retour.getY(), "RETOUR", Color.white);
		ttf.drawString(recommencer.getX(), recommencer.getY(), "RECOMMENCER", Color.white);

	}

	public void dessinervictoire(Graphics g, Menu m) throws IOException {
		int max = 0;
		int sco = Integer.parseInt(Menu.getScore());

		if (m.getElement() == 1) {
			g.setColor(new Color(100, 100, 255, 200));
			g.fillRect(0, 240, 890, 120);
			Font font = new Font("calibri", Font.BOLD, 70);
			TrueTypeFont ttf = new TrueTypeFont(font, true);
			ttf.drawString(300, 270, "NIVEAU 2", Color.green);
		}
		if (m.getElement() == 5) {
			g.setColor(new Color(100, 100, 255, 200));
			g.fillRect(0, 240, 890, 120);
			Font font = new Font("calibri", Font.BOLD, 70);
			TrueTypeFont ttf = new TrueTypeFont(font, true);
			ttf.drawString(300, 270, "NIVEAU 3", Color.green);

		}
		if (m.getElement() == 6) {
			g.setColor(new Color(100, 100, 255, 200));
			g.fillRect(0, 140, 890, 250);
			Font font = new Font("calibri", Font.BOLD, 35);
			TrueTypeFont ttf = new TrueTypeFont(font, true);

			if (multijoueur) {
				if (scoreJ1 == scoreJ2) {
					ttf.drawString(100, 170, "EGALITE ENTRE LE JOUEUR 1 ET LE JOUEUR 2!!", Color.green);
					ttf.drawString(300, 220, " DEUX GENIES!!!",  Color.green);
					ttf.drawString(280, 330, "O: OUI          N:  NON", Color.green);
					ttf.drawString(270, 290, "Voulez vouz rejouez?", Color.green);
					max = scoreJ1;
				} else if (scoreJ1 < scoreJ2) {
					ttf.drawString(100, 170, "LE GAGNANT ET LE GENIE DANS CETTE PARTIE EST LE JOUEUR 2", Color.green);
					ttf.drawString(270, 290, "Voulez vouz rejouez?", Color.green);
					ttf.drawString(280, 330, "O: OUI          N:  NON", Color.green);
					max = scoreJ2;
				} else {
					ttf.drawString(100, 170, "LE GAGNANT ET LE GENIE DANS CETTE PARTIE EST LE JOUEUR 1", Color.green);
					ttf.drawString(270, 290, "Voulez vouz rejouez?", Color.green);
					ttf.drawString(280, 330, "O: OUI          N:  NON", Color.green);
					max = scoreJ1;
				}
			} else {
				ttf.drawString(240, 210, "VOUS AVEZ UN SCORE DE " + scoreJ1, Color.green);
				ttf.drawString(270, 290, "Voulez vouz rejouez?", Color.green);
				ttf.drawString(280, 330, "O: OUI          N:  NON", Color.green);
				max = scoreJ1;
			}

		}
		if (max > sco) {
			// sco=max
			Menu.setScore("" + max);
			ecriture.println();
			ecriture.print(max);
			ecriture.close();
		}

	}

	public void dessinnerMultijoueur(Graphics g) {
		
		g.setColor(new Color(100, 100, 255, 200));
		g.fillRect(0, 240, 890, 120);
		Font font = new Font("calibri", Font.BOLD, 35);
		TrueTypeFont ttf = new TrueTypeFont(font, true);
		ttf.drawString(240, 280, "S: SOLO          M:  MULTIJOUEUR", Color.green);

	}

	public int[] getClick1() {
		return click1;
	}

	public void setClick1(int[] click1) {
		this.click1 = click1;
	}

	public int[] getClick2() {
		return click2;
	}

	public void setClick2(int[] click2) {
		this.click2 = click2;
	}

	public int[] getClick3() {
		return click3;
	}

	public void setClick3(int[] click3) {
		this.click3 = click3;
	}

	public static boolean isMultijoueur() {
		return multijoueur;
	}

	public static boolean isPartieEnCours() {
		return partieEnCours;
	}

	public static void setMultijoueur(boolean multijoueur) {
		Fenetre.multijoueur = multijoueur;
	}

	public static void setPartieEnCours(boolean partieEnCours) {
		Fenetre.partieEnCours = partieEnCours;
	}

	public void vider() {
		for (int i = 0; i < cases3.length; i++) {
			for (int j = 0; j < cases3[i].length; j++) {
				cases3[i][j] = null;
				cartes3[i][j] = null;
			}
		}

		for (int i = 0; i < cases1.length; i++) {
			for (int j = 0; j < cases1[i].length; j++) {
				cases1[i][j] = null;
				cartes1[i][j] = null;
			}
		}
		
		for (int i = 0; i < cases2.length; i++) {
			for (int j = 0; j < cases2[i].length; j++) {
				cases2[i][j] = null;
				cartes2[i][j] = null;
			}
		}
	}

}
