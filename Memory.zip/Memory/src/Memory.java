import java.io.IOException;

import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

public class Memory extends BasicGame {

	private Menu menu;
	private Theme theme;
	private Fenetre fenetre;
	private Aide aide;


	public Memory(String title) {
		super(title);

	}

	public void init(GameContainer gc) throws SlickException {

		theme = new Theme();
		menu = new Menu();
		fenetre = new Fenetre();
		aide = new Aide();
		String c = "", c1 = "";
		try {
			do {
				c1 = c;
				c = Fenetre.lecture.readLine();
			} while (c != null);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Menu.setScore(c1);
		
		fenetre.music.loop();

	}

	public void render(GameContainer gc, Graphics g) throws SlickException {
		switch (menu.getElement()) {
		case -1:
			g.drawImage(new Image("Images/menu.jpg"), 0, 0);
			if (Fenetre.isPartieEnCours() == false) {
				fenetre.dessinnerMultijoueur(g);
			}
			break;
		case 0:
			g.drawImage(new Image("Images/menu.jpg"), 0, 0);
			menu.dessinerHover(gc, g);
			menu.afficherMenu();
			break;
		case 1:
			fenetre.dessinerFenetre(g, menu);
			fenetre.dessinerHover(gc, g, menu);

			if (fenetre.fenetreVide(menu)) {
				try {
					fenetre.dessinervictoire(g, menu);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			break;
		case 2:
			theme.dessinerTheme(g);
			theme.dessinerHover(g, gc);
			break;
		case 3:
			aide.dessinerAide(g);
			aide.dessinerHover(gc, g);
			break;
		case 5:
			fenetre.dessinerFenetre(g, menu);
			if (fenetre.fenetreVide(menu)) {
				try {
					fenetre.dessinervictoire(g, menu);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			fenetre.dessinerHover(gc, g, menu);
			break;
		case 6:
			fenetre.dessinerFenetre(g, menu);
			if (fenetre.fenetreVide(menu)) {
				try {
					fenetre.dessinervictoire(g, menu);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			fenetre.dessinerHover(gc, g, menu);
			break;
		}

	}

	public void update(GameContainer gc, int delta) throws SlickException {
		Input input = gc.getInput();
		switch (menu.getElement()) {

		case -1:
			if (Fenetre.isPartieEnCours() == false) {
				if (input.isKeyPressed(Input.KEY_M)) {
					menu.setElement(1);
					Fenetre.setPartieEnCours(true);
					Fenetre.setMultijoueur(true);
				} else if (input.isKeyPressed(Input.KEY_S)) {
					menu.setElement(1);
					Fenetre.setPartieEnCours(true);
					Fenetre.setMultijoueur(false);
				}
			}
			break;
		case 0:
			if (input.isMousePressed(Input.MOUSE_LEFT_BUTTON)) {
				menu.clicCase(input.getMouseX(), input.getMouseY(), fenetre);
			}
			break;
		case 1:
			if (fenetre.fenetreVide(menu)) {
				if (input.isMousePressed(Input.MOUSE_LEFT_BUTTON)) {
					menu.setElement(5);
				}
			} else {
				if (fenetre.getClick2() == null) {
					if (input.isMousePressed(Input.MOUSE_LEFT_BUTTON)) {
						fenetre.clicReccomencer(input.getMouseX(), input.getMouseY(), menu);
						fenetre.clicRetour(input.getMouseX(), input.getMouseY(), menu);
						if (fenetre.isRecommencer(input.getMouseX(), input.getMouseY(), menu)) {
							fenetre = new Fenetre();
						}
						if (fenetre.getClick1() == null) {
							fenetre.click1(input.getMouseX(), input.getMouseY(), menu);
						} else {
							fenetre.click2(input.getMouseX(), input.getMouseY(), menu);
						}
					}
				} else {
					try {
						fenetre.comparer(menu);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			break;
		case 2:
			if (input.isMousePressed(Input.MOUSE_LEFT_BUTTON)) {
				theme.clicCase(input.getMouseX(), input.getMouseY());
				theme.retour(menu, input.getMouseX(), input.getMouseY(), fenetre);
				if (menu.getElement() == 0) {
					fenetre = new Fenetre();
				}
			}
			break;
		case 3:
			if (input.isMousePressed(Input.MOUSE_LEFT_BUTTON)) {
				aide.clicRetour(input.getMouseX(), input.getMouseY(), menu, fenetre);
			}
			break;
		case 4:
			gc.exit();
			break;
		case 5:
			if (fenetre.fenetreVide(menu)) {
				if (input.isMousePressed(Input.MOUSE_LEFT_BUTTON)) {
					menu.setElement(6);
				}
			} else {
				if (fenetre.getClick3() == null) {
					if (input.isMousePressed(Input.MOUSE_LEFT_BUTTON)) {
						fenetre.clicReccomencer(input.getMouseX(), input.getMouseY(), menu);
						fenetre.clicRetour(input.getMouseX(), input.getMouseY(), menu);
						if (fenetre.isRecommencer(input.getMouseX(), input.getMouseY(), menu)) {
							fenetre = new Fenetre();
						}
						if (fenetre.getClick2() == null) {
							if (fenetre.getClick1() == null) {
								fenetre.click1(input.getMouseX(), input.getMouseY(), menu);
							} else {
								fenetre.click2(input.getMouseX(), input.getMouseY(), menu);
							}
						} else {
							fenetre.click3(input.getMouseX(), input.getMouseY(), menu);
						}

					}
				} else {
					try {
						fenetre.comparer(menu);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			break;
		case 6:
			fenetre.deplacerLesCartes(gc, delta);
			if (fenetre.fenetreVide(menu)) {
				if (input.isKeyPressed(Input.KEY_O)) {
					menu.setElement(-1);
					fenetre = new Fenetre();
				}
				if (input.isKeyPressed(Input.KEY_N)) {
					menu.setElement(0);
					fenetre = new Fenetre();
				}
			} else {
				if (fenetre.getClick3() == null) {
					if (input.isMousePressed(Input.MOUSE_LEFT_BUTTON)) {
						fenetre.clicReccomencer(input.getMouseX(), input.getMouseY(), menu);
						fenetre.clicRetour(input.getMouseX(), input.getMouseY(), menu);
						if (fenetre.isRecommencer(input.getMouseX(), input.getMouseY(), menu)) {
							fenetre = new Fenetre();
						}
						if (fenetre.getClick2() == null) {
							if (fenetre.getClick1() == null) {
								fenetre.click1(input.getMouseX(), input.getMouseY(), menu);
							} else {
								fenetre.click2(input.getMouseX(), input.getMouseY(), menu);
							}
						} else {
							fenetre.click3(input.getMouseX(), input.getMouseY(), menu);
						}

					}
				} else {
					try {
						fenetre.comparer(menu);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			break;
		}

	}

}
