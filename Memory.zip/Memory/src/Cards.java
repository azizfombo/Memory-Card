import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

public class Cards {
	private int type;
	private float x, y;
	private Image imgvoir, imgcache;
	private boolean esttourner;
	private static int themevoir = 0, themecache = 0;

	//CONSTRUCTEUR POUR LE THEME
	public Cards(double element, int x, int y) throws SlickException {
		this.x = x;
		this.y = y;
		if (element == 1)
			imgvoir = new Image("Images/theme1.jpg");
		if (element == 2)
			imgvoir = new Image("Images/theme2.jpg");
		if (element == 3)
			imgvoir = new Image("Images/theme3.jpg");
		if (element == 4)
			imgvoir = new Image("Images/themec1.jpg");
		if (element == 5)
			imgvoir = new Image("Images/themec2.jpg");
		if (element == 6)
			imgvoir = new Image("Images/themec3.jpg");
	}

	// CONSTRUCTEUR POUR LES CARTES DU JEU
	public Cards(int type, int x, int y) throws SlickException {
		super();
		this.type = type;
		this.esttourner = false;
		this.x = x;
		this.y = y;
		if (themecache == 0)
			imgcache = new Image("Images/back1.jpg");
		else if (themecache == 1)
			imgcache = new Image("Images/back2.jpg");
		else
			imgcache = new Image("Images/back3.jpg");
		if (themevoir == 0) {
			switch (this.type) {
			case 1:
				imgvoir = new Image("Images/t1img1.png");
				break;
			case 2:
				imgvoir = new Image("Images/t1img2.png");
				break;
			case 3:
				imgvoir = new Image("Images/t1img3.png");
				break;
			case 4:
				imgvoir = new Image("Images/t1img4.png");
				break;
			case 5:
				imgvoir = new Image("Images/t1img5.png");
				break;
			case 6:
				imgvoir = new Image("Images/t1img6.png");
				break;
			case 7:
				imgvoir = new Image("Images/t1img7.png");
				break;
			case 8:
				imgvoir = new Image("Images/t1img8.png");
				break;
			}
		} else if (themevoir == 1) {
			switch (this.type) {
			case 1:
				imgvoir = new Image("Images/t2img1.png");
				break;
			case 2:
				imgvoir = new Image("Images/t2img2.png");
				break;
			case 3:
				imgvoir = new Image("Images/t2img3.png");
				break;
			case 4:
				imgvoir = new Image("Images/t2img4.png");
				break;
			case 5:
				imgvoir = new Image("Images/t2img5.png");
				break;
			case 6:
				imgvoir = new Image("Images/t2img6.png");
				break;
			case 7:
				imgvoir = new Image("Images/t2img7.png");
				break;
			case 8:
				imgvoir = new Image("Images/t2img8.png");
				break;
			}
		} else {
			switch (this.type) {
			case 1:
				imgvoir = new Image("Images/t3img1.png");
				break;
			case 2:
				imgvoir = new Image("Images/t3img2.png");
				break;
			case 3:
				imgvoir = new Image("Images/t3img3.png");
				break;
			case 4:
				imgvoir = new Image("Images/t3img4.png");
				break;
			case 5:
				imgvoir = new Image("Images/t3img5.png");
				break;
			case 6:
				imgvoir = new Image("Images/t3img6.png");
				break;
			case 7:
				imgvoir = new Image("Images/t3img7.png");
				break;
			case 8:
				imgvoir = new Image("Images/t3img8.png");
				break;
			}
		}
	}
	
	//DEPLACER LES CARTES SELON LES CASES
	public void deplacerCartes(Case c) {
		if(c!=null) {
			this.setX(c.getX()+5);
			this.setY(c.getY()+5);
		}
		
	}
	
	// DESSINER LES CARTES DU JEU
	public void dessinerCarte(Graphics g) throws SlickException {
		if (esttourner) {
			g.drawImage(imgvoir, x, y);
		} else
			g.drawImage(imgcache, x, y);
		g.setColor(Color.blue);
		for (int i = -1; i < 1; i++) {
			g.drawRoundRect(x + i, y + i, 110 - 2 * i, 110 - 2 * i, 5);
		}
	}

	//DESSINER LES CARTES DU THEMES
	public void dessineCarte(Graphics g) {
		g.drawImage(imgvoir, x, y);
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public Image getImgvoir() {
		return imgvoir;
	}

	public void setImgvoir(Image imgvoir) {
		this.imgvoir = imgvoir;
	}

	public Image getImgcache() {
		return imgcache;
	}

	public void setImgcache(Image imgcache) {
		this.imgcache = imgcache;
	}

	public boolean istourner() {
		return esttourner;
	}

	public void setEsttourner(boolean esttourner) {
		this.esttourner = esttourner;
	}

	public static int getThemevoir() {
		return themevoir;
	}

	public static void setThemevoir(int themevoir) {
		Cards.themevoir = themevoir;
	}

	public static int getThemecache() {
		return themecache;
	}

	public static void setThemecache(int themecache) {
		Cards.themecache = themecache;
	}
	
	

}
