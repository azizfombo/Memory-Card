import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.SlickException;

public class MainMemory {

	public static void main(String[] args) throws SlickException {
		// TODO Auto-generated method stub
		AppGameContainer app = new AppGameContainer(new Memory("JEU DE MEMOIRE"));
		app.setTargetFrameRate(60);
		app.setFullscreen(true);
		app.setShowFPS(false);
		app.setDisplayMode(890, 600, false);
		app.start();
	}

}
